const songController = require('./songController');

module.exports = {
  ...songController,
};
