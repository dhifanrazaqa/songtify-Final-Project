const express = require('express');
const songRoutes = require('./songRoutes');

const router = express.Router();

router.use('', songRoutes);

module.exports = router;
