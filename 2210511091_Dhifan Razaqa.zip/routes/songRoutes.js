const express = require('express');
const { getAllSongs, getSongById, createSong } = require('../controllers');
const validate = require('../middleware/form-validation/song');

const router = express.Router();

router.get('/songs', getAllSongs);
router.get('/song/:id', getSongById);
router.post('/song', validate, createSong);

module.exports = router;
